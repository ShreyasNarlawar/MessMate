package com.spooncode;
import com.spooncode.SignupLogin.firebaseConfig.DataService;
import com.spooncode.SignupLogin.initialize.InitializeApp;

import javafx.application.Application;
class NetworkThread extends Thread{

   public void run(){
    System.out.println(Thread.currentThread());
    DataService dataService=new DataService(null);
    }
}


public class Main {
    
    public static void main(String[] args) {
        System.out.println("MessMate.in");
        System.out.println(Thread.currentThread());
        NetworkThread nt=new NetworkThread();
        nt.start();
        Application.launch(InitializeApp.class,args);
    }
}
