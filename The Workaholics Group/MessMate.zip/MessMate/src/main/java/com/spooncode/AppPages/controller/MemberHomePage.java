package com.spooncode.AppPages.controller;

import java.io.IOException;
import java.util.concurrent.ExecutionException;

import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

//This class is for showing Homepage of Member after login
public class MemberHomePage /*extends SecondPage*/{
    Stage primaryStage;

    public MemberHomePage(Stage primaryStage) throws InterruptedException, ExecutionException, IOException{
       //super(primaryStage);
        //this.primaryStage=primaryStage;
    }
    public void memberPage(Stage primaryStage){
        this.primaryStage=primaryStage;
        

    }
}
